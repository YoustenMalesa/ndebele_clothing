<?php
	 $connect = mysqli_connect("localhost", "root","","db_ndebele");
?>