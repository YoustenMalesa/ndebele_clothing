<?php
	require 'connect.php';

	$action = NULL;
	if(isset($_GET['action'])){$action = $_GET['action'];}




?>